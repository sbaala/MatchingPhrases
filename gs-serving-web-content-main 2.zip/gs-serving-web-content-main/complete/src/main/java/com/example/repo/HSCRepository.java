package com.example.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.model.Hsc;

public interface HSCRepository extends JpaRepository<Hsc, Integer>{
	
	@Query("SELECT COALESCE(MAX(e.hscCode),101) FROM Hsc e")
	 Optional<Integer> findTopHSCJQPL();


}
