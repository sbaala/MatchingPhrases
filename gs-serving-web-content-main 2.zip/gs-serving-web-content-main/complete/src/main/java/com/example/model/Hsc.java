package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dph_master_hsc")
public class Hsc {
	

	   @Id
	   @Column(name = "hsc_code")
	   private Integer hscCode;
	    
	   @Column(name = "hsc_name")
	   private String hscName;
	   
	   @Column(name = "phc_code")
	   private Integer phcCode;
	   
	   
	   @Column(name="rural_or_urban")
	   private String ruralUrban;


	

	public int getHscCode() {
		return hscCode;
	}


	public void setHscCode(int hscCode) {
		this.hscCode = hscCode;
	}


	public String getHscName() {
		return hscName;
	}


	public void setHscName(String hscName) {
		this.hscName = hscName;
	}


	public Integer getPhcCode() {
		return phcCode;
	}


	public void setPhcCode(Integer phcCode) {
		this.phcCode = phcCode;
	}


	public String getRuralUrban() {
		return ruralUrban;
	}


	public void setRuralUrban(String ruralUrban) {
		this.ruralUrban = ruralUrban;
	}
	   
	   
	   

}
