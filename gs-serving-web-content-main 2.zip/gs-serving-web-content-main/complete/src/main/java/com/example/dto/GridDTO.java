package com.example.dto;

import java.util.List;

public class GridDTO {
	
	List<LoadGridData> records;
	
	Integer total;

	public List<LoadGridData> getRecords() {
		return records;
	}

	public void setRecords(List<LoadGridData> records) {
		this.records = records;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	
}
