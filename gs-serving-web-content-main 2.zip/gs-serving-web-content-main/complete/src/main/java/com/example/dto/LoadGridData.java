package com.example.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class LoadGridData {
		
	
	private int distCode;
	
	private int hudCode;
	
	private int blockCode;
	
	private int phcCode;
	
	private int hscCode;
	
	
	private String distName;
	
	private String hudName;
	
	private String blockName;
	
	private String phcName;
	
	private String hscName;
	
	private String ruralUrban;
	
	

	public LoadGridData(int distCode, int hudCode, int blockCode, int phcCode, int hscCode, String distName,
			String hudName, String blockName, String phcName, String hscName, String ruralUrban) {
		super();
		this.distCode = distCode;
		this.hudCode = hudCode;
		this.blockCode = blockCode;
		this.phcCode = phcCode;
		this.hscCode = hscCode;
		this.distName = distName;
		this.hudName = hudName;
		this.blockName = blockName;
		this.phcName = phcName;
		this.hscName = hscName;
		this.ruralUrban = ruralUrban;
	}

	public int getDistCode() {
		return distCode;
	}

	public void setDistCode(int distCode) {
		this.distCode = distCode;
	}

	public int getHudCode() {
		return hudCode;
	}

	public void setHudCode(int hudCode) {
		this.hudCode = hudCode;
	}

	public int getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(int blockCode) {
		this.blockCode = blockCode;
	}

	public int getPhcCode() {
		return phcCode;
	}

	public void setPhcCode(int phcCode) {
		this.phcCode = phcCode;
	}

	public int getHscCode() {
		return hscCode;
	}

	public void setHscCode(int hscCode) {
		this.hscCode = hscCode;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getHudName() {
		return hudName;
	}

	public void setHudName(String hudName) {
		this.hudName = hudName;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public String getPhcName() {
		return phcName;
	}

	public void setPhcName(String phcName) {
		this.phcName = phcName;
	}

	public String getHscName() {
		return hscName;
	}

	public void setHscName(String hscName) {
		this.hscName = hscName;
	}

	public String getRuralUrban() {
		return ruralUrban;
	}

	public void setRuralUrban(String ruralUrban) {
		this.ruralUrban = ruralUrban;
	}
	
	
	

}
