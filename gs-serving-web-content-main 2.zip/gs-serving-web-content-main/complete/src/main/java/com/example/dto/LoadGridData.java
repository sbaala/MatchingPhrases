package com.example.dto;

public class LoadGridData {
		
	
	private int distCode;
	
	private int hudCode;
	
	private Integer blockCode;
	
	private Integer phcCode;
	
	private Integer hscCode;
	
	
	private String distName;
	
	private String hudName;
	
	private String blockName;
	
	private String phcName;
	
	private String hscName;
	
	private String ruralUrban;
	
	

	public LoadGridData(int distCode, String distName, int hudCode, String hudName, Integer blockCode, String blockName, Integer phcCode,  String phcName,
			 String ruralUrban, Integer hscCode,  String hscName) {
		super();
		this.distCode = distCode;
		this.hudCode = hudCode;		
        this.blockCode =blockCode != null ? blockCode : 0;
		this.phcCode = phcCode != null? phcCode : 0;
		this.hscCode = hscCode != null? hscCode : 0;
		this.distName = distName;
		this.hudName = hudName;
		this.blockName = blockName !=null ? blockName : "";
		this.phcName = phcName != null ? phcName : "";
		this.hscName = hscName !=null ? hscName : "";
		this.ruralUrban = ruralUrban !=null ? ruralUrban: "";
	}

	public int getDistCode() {
		return distCode;
	}

	public void setDistCode(int distCode) {
		this.distCode = distCode;
	}

	public int getHudCode() {
		return hudCode;
	}

	public void setHudCode(int hudCode) {
		this.hudCode = hudCode;
	}

	public int getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(int blockCode) {
		this.blockCode = blockCode;
	}

	public int getPhcCode() {
		return phcCode;
	}

	public void setPhcCode(int phcCode) {
		this.phcCode = phcCode;
	}

	public int getHscCode() {
		return hscCode;
	}

	public void setHscCode(int hscCode) {
		this.hscCode = hscCode;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getHudName() {
		return hudName;
	}

	public void setHudName(String hudName) {
		this.hudName = hudName;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public String getPhcName() {
		return phcName;
	}

	public void setPhcName(String phcName) {
		this.phcName = phcName;
	}

	public String getHscName() {
		return hscName;
	}

	public void setHscName(String hscName) {
		this.hscName = hscName;
	}

	public String getRuralUrban() {
		return ruralUrban;
	}

	public void setRuralUrban(String ruralUrban) {
		this.ruralUrban = ruralUrban;
	}
	
	
	

}
