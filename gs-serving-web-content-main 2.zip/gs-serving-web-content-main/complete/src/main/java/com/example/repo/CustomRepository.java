package com.example.repo;

import java.util.List;

import com.example.dto.LoadGridData;

public interface CustomRepository {

	 List<LoadGridData> findAllDetails();
	
}
