package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dph_master_phc")
public class Phc {
	
	   @Id
	   @Column(name = "phc_code")
	   private Integer phcCode;
	    
	   @Column(name = "phc_name")
	   private String phcName;
	   
	   @Column(name = "block_code")
	   private Integer blockCode;
	   
	   
	   @Column(name="rural_or_urban")
	   private String ruralUrban;


	

	public int getPhcCode() {
		return phcCode;
	}


	public void setPhcCode(Integer phcCode) {
		this.phcCode = phcCode;
	}


	public String getPhcName() {
		return phcName;
	}


	public void setPhcName(String phcName) {
		this.phcName = phcName;
	}


	public Integer getBlockCode() {
		return blockCode;
	}


	public void setBlockCode(Integer blockCode) {
		this.blockCode = blockCode;
	}


	public String getRuralUrban() {
		return ruralUrban;
	}


	public void setRuralUrban(String ruralUrban) {
		this.ruralUrban = ruralUrban;
	}


}
