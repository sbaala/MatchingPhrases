package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.dto.LoadGridData;
import com.example.model.District;



public interface DistrictRepository extends JpaRepository<District, Long> {
    // You can add custom query methods here if needed

	@Query(value="select dist.dist_code as distCode, dist.dist_name as distName, hud.hud_code as hudCode, hud.hud_name as hudName, blk.block_code as blockCode, blk.block_name as blockName, phc.phc_code as phcCode, phc.phc_name as phcName, phc.Rural_or_urban as ruralUrban, hsc.hsc_code as hscCode, hsc.hsc_name as hscName from \r\n"
			+ "(select dist_code, dist_name from dph_master_dist) dist\r\n"
			+ "left join\r\n"
			+ "(select hud_code, hud_name, dist_code  from dph_master_hud) hud \r\n"
			+ "on dist.dist_code = hud.dist_code\r\n"
			+ "left join\r\n"
			+ "(select block_code, block_name, hud_code from dph_master_block) blk\r\n"
			+ "on hud.hud_code = blk.hud_code\r\n"
			+ "left join\r\n"
			+ "(select phc_code, phc_name, Rural_or_urban, block_code  from dph_master_phc) phc\r\n"
			+ "on blk.block_code = phc.block_code\r\n"
			+ "left join\r\n"
			+ "(select hsc_code, hsc_name, phc_code from dph_master_hsc) hsc\r\n"
			+ "on phc.phc_code = hsc.phc_code", nativeQuery = true)
	 List<LoadGridData> findAllDetails();
}
