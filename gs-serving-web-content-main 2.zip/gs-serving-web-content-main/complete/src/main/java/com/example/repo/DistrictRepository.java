package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.dto.LoadGridData;
import com.example.model.District;



public interface DistrictRepository extends JpaRepository<District, Long> {
    // You can add custom query methods here if needed

	@Query("select new com.example.dto.LoadGridData( dist.distCode, dist.distName, hud.hudCode, hud.hudName, blk.blockCode, blk.blockName, phc.phcCode, phc.phcName, phc.ruralUrban, hsc.hscCode, hsc.hscName) from \r\n"
			+ " District dist\r\n"
			+ "left join\r\n"
			+ " Hud hud \r\n"
			+ "on dist.distCode = hud.distCode\r\n"
			+ "left join\r\n"
			+ " Block blk\r\n"
			+ "on hud.hudCode = blk.hudCode\r\n"
			+ "left join\r\n"
			+ " Phc phc\r\n"
			+ "on blk.blockCode = phc.blockCode\r\n"
			+ "left join\r\n"
			+ " Hsc hsc\r\n"
			+ "on phc.phcCode = hsc.phcCode order by phc.phcCode")
	 List<LoadGridData> findAllDetails();
}
