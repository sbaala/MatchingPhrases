package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.LoadGridData;
import com.example.dto.SaveMasterData;
import com.example.model.Hud;
import com.example.repo.DistrictRepository;
import com.example.repo.HudRepository;

@RestController
public class PersonController {

  
    
    @Autowired DistrictRepository gridrepo;
    
    @Autowired HudRepository hudrepo;
    
	/*
	 * @GetMapping("/api/grid") public List<Person> getAllPersons() { // Sample data
	 * System.out.println("persionsssss"); return Arrays.asList( new Person(1L,
	 * "John Doe", "USA", new Date(90, 1, 1), true), new Person(2L, "Jane Smith",
	 * "UK", new Date(85, 5, 20), false), new Person(3L, "Juan Carlos", "Spain", new
	 * Date(78, 10, 15), true) ); }
	 */
    
    
    @GetMapping("/api/grid")
    public List<LoadGridData> getAllDistricts() {
     //Object[] obj = gridrepo.findAllDetails();	
	 return gridrepo.findAllDetails();
    }


}

