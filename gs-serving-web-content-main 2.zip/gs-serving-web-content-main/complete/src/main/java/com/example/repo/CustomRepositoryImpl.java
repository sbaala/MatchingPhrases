package com.example.repo;

import java.util.List;

import com.example.dto.LoadGridData;

public class CustomRepositoryImpl implements CustomRepository {

    
	@Override
	public List<LoadGridData> findAllDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
