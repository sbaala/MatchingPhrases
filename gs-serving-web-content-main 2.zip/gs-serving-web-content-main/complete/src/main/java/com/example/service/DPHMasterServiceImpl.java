package com.example.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.SaveMasterData;
import com.example.model.Block;
import com.example.model.Hsc;
import com.example.model.Phc;
import com.example.repo.BlockRepository;
import com.example.repo.HSCRepository;
import com.example.repo.PHCRepository;

@Service
public class DPHMasterServiceImpl implements DPHMasterService {
	
	@Autowired
	BlockRepository blockRepository;
	
	@Autowired
	HSCRepository hscRepository;
	
	@Autowired
	PHCRepository phcRepository;
		

	@Override
	public void dphDataCreation(SaveMasterData saveMasterData) {
		
		Optional<Integer> maxValue = blockRepository.findMaxBlockCode();
		
		
		Block block = new Block();
		if( maxValue.isPresent())
			block.setBlockCode(maxValue.get()+1);
		else
			block.setBlockCode(101);
		
		block.setBlockName(saveMasterData.getBlk());
		block.setHudCode(saveMasterData.getHud());
		
		blockRepository.save(block);
		
		Optional<Integer> maxValuePhc = phcRepository.findTopPHCJQPL();
		
		Phc phc = new Phc();
		
		if (maxValuePhc.isPresent())
			phc.setPhcCode(maxValuePhc.get()+1);
		else
			phc.setPhcCode(101);
		phc.setPhcName(saveMasterData.getPhc());
		phc.setBlockCode(block.getBlockCode());
		phc.setRuralUrban(saveMasterData.getRuralurban());
		
		phcRepository.save(phc);
		
		Optional<Integer> maxValueHsc = hscRepository.findTopHSCJQPL();
		
		Hsc hsc = new Hsc();
		
		if( maxValueHsc.isPresent())
			hsc.setHscCode(maxValueHsc.get()+1);
		else
			hsc.setHscCode(101);
		hsc.setHscName(saveMasterData.getHsc());
		hsc.setPhcCode(phc.getPhcCode());
		hsc.setRuralUrban(saveMasterData.getRuralurban());
		
		hscRepository.save(hsc);
		
	}

}
