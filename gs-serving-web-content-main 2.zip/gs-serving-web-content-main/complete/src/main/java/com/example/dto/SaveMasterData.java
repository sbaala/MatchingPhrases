package com.example.dto;

public class SaveMasterData {
	
	
	private int dist;
	
	private int hud;		
	
	private String rural;
	
	private String urban;
	
	private String blk;
	
	private String phc;
	
	private String hsc;
	
	private String ruralurban;
	
	

	public String getRuralurban() {
		return ruralurban;
	}

	public void setRuralurban(String ruralurban) {
		this.ruralurban = ruralurban;
	}

	public int getDist() {
		return dist;
	}

	public void setDist(int dist) {
		this.dist = dist;
	}

	

	public int getHud() {
		return hud;
	}

	public void setHud(int hud) {
		this.hud = hud;
	}



	public String getRural() {
		return rural;
	}

	public void setRural(String rural) {
		this.rural = rural;
	}

	public String getUrban() {
		return urban;
	}

	public void setUrban(String urban) {
		this.urban = urban;
	}

	public String getBlk() {
		return blk;
	}

	public void setBlk(String blk) {
		this.blk = blk;
	}

	public String getPhc() {
		return phc;
	}

	public void setPhc(String phc) {
		this.phc = phc;
	}

	public String getHsc() {
		return hsc;
	}

	public void setHsc(String hsc) {
		this.hsc = hsc;
	}
	
	

	

}
