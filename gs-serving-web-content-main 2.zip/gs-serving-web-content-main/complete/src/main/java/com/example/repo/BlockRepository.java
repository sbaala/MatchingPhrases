package com.example.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.model.Block;

@Repository
public interface BlockRepository extends JpaRepository<Block, Integer>{
	
	 @Query("SELECT COALESCE(MAX(e.blockCode), 101) FROM Block e")
	 Optional<Integer> findMaxBlockCode();


}
