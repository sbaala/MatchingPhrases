package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dph_master_block")
public class Block {

	@Id
	@Column(name = "block_code")
	private Integer blockCode;
	   
	@Column(name = "block_name")
	private String blockName;
	   
	@Column(name="rural_or_urban")
	private String ruralUrban;
	
	@Column(name="hud_code")
	private Integer hudCode;

	

	public Integer getHudCode() {
		return hudCode;
	}

	public void setHudCode(Integer hudCode) {
		this.hudCode = hudCode;
	}

	public int getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(Integer blockCode) {
		this.blockCode = blockCode;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public String getRuralUrban() {
		return ruralUrban;
	}

	public void setRuralUrban(String ruralUrban) {
		this.ruralUrban = ruralUrban;
	}

	  

}
