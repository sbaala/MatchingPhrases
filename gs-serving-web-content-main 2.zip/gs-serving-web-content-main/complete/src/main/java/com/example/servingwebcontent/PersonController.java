package com.example.servingwebcontent;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonController {

    @GetMapping("/api/persons")
    public List<Person> getAllPersons() {
        // Sample data
        return Arrays.asList(
                new Person(1L, "John Doe", "USA", new Date(90, 1, 1), true),
                new Person(2L, "Jane Smith", "UK", new Date(85, 5, 20), false),
                new Person(3L, "Juan Carlos", "Spain", new Date(78, 10, 15), true)
        );
    }
}

