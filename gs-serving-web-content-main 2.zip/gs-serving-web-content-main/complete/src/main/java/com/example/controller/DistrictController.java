package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dto.SaveMasterData;
import com.example.model.Hud;
import com.example.repo.DistrictRepository;
import com.example.repo.HudRepository;
import com.example.service.DPHMasterService;

@Controller
public class DistrictController {

	 @Autowired
	 private DistrictRepository districtRepository;
	 
	 @Autowired 
	 HudRepository hudRepository;
	 
	 @Autowired
	 DPHMasterService dphMasterService;
	 
	
	 
	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	
	@GetMapping("/welcome")
	public String welcome(Model model) {
		
		model.addAttribute("Hello", "Welcome Bala");
		
		return "welcome";
	}
	
	@GetMapping("/district")
	public String district(Model model) {
		
		System.out.println("testtttt");
		model.addAttribute("masterForm", new SaveMasterData());
		model.addAttribute("districts", districtRepository.findAll());
		
		return "district";
	}
	
    
    @PostMapping("/api/masters/save")
    @ResponseBody
    public String saveMasterData(@ModelAttribute SaveMasterData master, Model model){
    	
    	
    	dphMasterService.dphDataCreation(master);  	
    	
      
        return "success";
    }

	
	@GetMapping("/loadHud/{distId}")
    @ResponseBody
    public List<Hud> getHudByDistrict(@PathVariable("distId") Integer distId) {
        //District dist = repository.findById(distId).orElseThrow(() -> new IllegalArgumentException("Invalid state id"));
        return hudRepository.findByDistCode(distId);
    }
	
	
	
	
	    
}
