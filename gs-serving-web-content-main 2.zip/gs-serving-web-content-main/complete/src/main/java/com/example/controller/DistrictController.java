package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dto.GridDTO;
import com.example.dto.LoadGridData;
import com.example.dto.Sample;
import com.example.dto.SaveMasterData;
import com.example.model.Block;
import com.example.model.District;
import com.example.model.Hsc;
import com.example.model.Hud;
import com.example.model.Phc;
import com.example.repo.BlockRepository;
import com.example.repo.DistrictRepository;
import com.example.repo.HSCRepository;
import com.example.repo.HudRepository;
import com.example.repo.PHCRepository;
import com.example.service.DPHMasterService;

@Controller
public class DistrictController {

	 @Autowired
	 private DistrictRepository districtRepository;
	 
	 @Autowired 
	 HudRepository hudRepository;
	 
	 @Autowired
	 DPHMasterService dphMasterService;
	 
	 @Autowired
	 BlockRepository blockRepository;
	 
	 @Autowired
	 HSCRepository hscRepository;
	 
	 @Autowired
	 PHCRepository phcRepository;
	 
	
	 
	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	
	@GetMapping("/welcome")
	public String welcome(Model model) {
		
		model.addAttribute("Hello", "Welcome Bala");
		
		return "welcome";
	}
	
	@GetMapping("/district")
	public String district(Model model) {
		
		System.out.println("testtttt");
		model.addAttribute("masterForm", new SaveMasterData());
		model.addAttribute("districts", districtRepository.findAll());
		
		return "district";
	}
	
    
    @PostMapping("/api/masters/save")
    public String saveMasterData(@ModelAttribute SaveMasterData master, Model model){
    	
    	
    	dphMasterService.dphDataCreation(master);  	
    	
      
        return "redirect:/district";
    }

	
	@GetMapping("/loadHud/{distId}")
    @ResponseBody
    public List<Hud> getHudByDistrict(@PathVariable("distId") Integer distId) {
        //District dist = repository.findById(distId).orElseThrow(() -> new IllegalArgumentException("Invalid state id"));
        return hudRepository.findByDistCode(distId);
    }
	
    @GetMapping("/api/grid")
    @ResponseBody
    public GridDTO getAllDetails( @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int limit) {
    
	 List<LoadGridData> listGrid = districtRepository.findAllDetails();
	 
	 GridDTO gridDTO = new GridDTO();
	 
	 
	 
	 Integer start = (page*limit)-limit;
	 Integer end = start+limit;
	 
	 if(end>listGrid.size())
		 end=listGrid.size();
	 
     List<LoadGridData> subList = listGrid.subList(start, end);
     
     gridDTO.setRecords(subList);
     gridDTO.setTotal(listGrid.size());

	 
	 return gridDTO;
    }
	
	@GetMapping("/api/districts")
    @ResponseBody
    public List<Sample> getAllDistrict() {
        
        List<District> districts = districtRepository.findAll();
        
        List<Sample> sampleList = new ArrayList<Sample>();
        
        for (District district : districts) {
            Sample sample = new Sample();
            sample.setId( district.getDistCode());
            sample.setText(district.getDistName());
            sample.setChecked(false);
            sample.setChildren(null);
            sample.setHasChildren(false);
            
            sampleList.add(sample);
        }
        
        return sampleList;
    }
	
	@GetMapping("/api/huds")
    @ResponseBody
    public List<Sample> getAllHuds() {
        
        List<Hud> huds = hudRepository.findAll();
        
        List<Sample> sampleList = new ArrayList<Sample>();
        
        for (Hud district : huds) {
            Sample sample = new Sample();
            sample.setId( district.getHudCode());
            sample.setText(district.getHudName());
            sample.setChecked(false);
            sample.setChildren(null);
            sample.setHasChildren(false);
            
            sampleList.add(sample);
        }
        
        return sampleList;
    }
	
	@GetMapping("/api/blocks")
    @ResponseBody
    public List<Sample> getAllBlocks() {
        
        List<Block> blocks = blockRepository.findAll();
        
        List<Sample> sampleList = new ArrayList<Sample>();
        
        for (Block block : blocks) {
            Sample sample = new Sample();
            sample.setId( block.getBlockCode());
            sample.setText(block.getBlockName());
            sample.setChecked(false);
            sample.setChildren(null);
            sample.setHasChildren(false);
            
            sampleList.add(sample);
        }
        
        return sampleList;
    }
	
	@GetMapping("/api/phcs")
    @ResponseBody
    public List<Sample> getAllPhcs() {
        
        List<Phc> phcs = phcRepository.findAll();
        
        List<Sample> sampleList = new ArrayList<Sample>();
        
        for (Phc phc : phcs) {
            Sample sample = new Sample();
            sample.setId( phc.getPhcCode());
            sample.setText(phc.getPhcName());
            sample.setChecked(false);
            sample.setChildren(null);
            sample.setHasChildren(false);
            
            sampleList.add(sample);
        }
        
        return sampleList;
    }
	
	@GetMapping("/api/hscs")
    @ResponseBody
    public List<Sample> getAllHscs() {
        
        List<Hsc> phcs = hscRepository.findAll();
        
        List<Sample> sampleList = new ArrayList<Sample>();
        
        for (Hsc hsc : phcs) {
            Sample sample = new Sample();
            sample.setId( hsc.getHscCode());
            sample.setText(hsc.getHscName());
            sample.setChecked(false);
            sample.setChildren(null);
            sample.setHasChildren(false);
            
            sampleList.add(sample);
        }
        
        return sampleList;
    }
	    
}
