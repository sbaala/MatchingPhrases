package com.example.service;

import com.example.dto.SaveMasterData;

public interface DPHMasterService {

	void dphDataCreation( SaveMasterData saveMasterData);
}
