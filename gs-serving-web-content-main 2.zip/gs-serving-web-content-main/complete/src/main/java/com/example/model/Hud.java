package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "dph_master_hud")
public class Hud {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name="hud_code")
	private int hudCode;
	
	@Column(name="hud_name")
	private String hudName;
	
	@Column(name="dist_code")
	private int distCode;
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getDistCode() {
		return distCode;
	}
	public void setDistCode(int distCode) {
		this.distCode = distCode;
	}
	public int getHudCode() {
		return hudCode;
	}
	public void setHudCode(int hudCode) {
		this.hudCode = hudCode;
	}
	public String getHudName() {
		return hudName;
	}
	public void setHudName(String hudName) {
		this.hudName = hudName;
	}
	
	
	
}
