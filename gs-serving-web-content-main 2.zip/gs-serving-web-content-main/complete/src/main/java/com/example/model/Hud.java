package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "dph_master_hud")
public class Hud {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int hud_code;
	private String hud_name;
	@Column(name="dist_code")
	private int distCode;
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getHud_code() {
		return hud_code;
	}
	public void setHud_code(int hud_code) {
		this.hud_code = hud_code;
	}
	public String getHud_name() {
		return hud_name;
	}
	public void setHud_name(String hud_name) {
		this.hud_name = hud_name;
	}
	public int getDistCode() {
		return distCode;
	}
	public void setDistCode(int distCode) {
		this.distCode = distCode;
	}
	
	
	
}
