package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Hud;

public interface HudRepository extends JpaRepository<Hud, Long>{

	List<Hud> findByDistCode(Integer distId);



}
